package guc.supermarket.products ;

public class  DairyProduct extends GroceryProduct {
	
	private Fat fat;
 
public DairyProduct(String name,double price,double discount,Fat fat) {
	super( name, price, discount);
	this.fat=fat;	
}
 
public Fat getFat() {
	return fat;
}

public void setFat(Fat fat) {
	this.fat = fat;
}

String getname(){
return super.getName();
}
void setName(String name){
super.setName(name);
}

void setPrice(double price) {
	super.setPrice(price);
}
 public double getPrice() {
	return super.getPrice();
}

void setDiscount(double discount) {
	super.setDiscount(discount);
}
public String toString() {
	return super.toString()+'\n'+"Fat Level:"+this.getFat();
}

}
