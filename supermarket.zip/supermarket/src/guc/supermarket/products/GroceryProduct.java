package guc.supermarket.products;

public class GroceryProduct {
	private String name;
	private double price;
	private double discount;
	public GroceryProduct(String name,double price,double discount) {
		this.name=name;
		this.price=price;
		this.discount=discount;

}
	String getName() {
		return this.name;
	}
	
		void setName(String name){
		this.name = name;
		}
		 public double getDiscount() {
			return this.discount;
		}
		
		void setPrice(double price) {
		//double newprice=price-((discount/100)*price);
		this.price=price;
		
		}
		void setDiscount(double discount) {
			this.discount=discount;
		}
		
		public double getPrice() {
			return this.price;
		}
	 public final  double getActualPrice() {
		 double amount=(discount/100)*price;
		 return price-amount;
		//System.out.println("the actual price should be "+newprice);
	 }
	 public String toString() {
		  return"Name:"+this.getName()+'\n'+"Price:"+this.getPrice()+"LE"+'\n'+"discount:"+this.getDiscount();
	  }
}
