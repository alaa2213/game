/**
 * 
 */
/**
 * 
 */
module supermarket {
	requires junit;
}